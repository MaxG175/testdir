#include "stdio.h"
#include "sum.h"

int main(int argc, char** argv){

	int result = 0;
	if(argc < 3){
	
		printf("Too few arguments\n");
	}
	else{
	
		result = Sum(atoi(argv[1]), atoi(argv[2]));
	}
	
	printf("sum = %d\n", result);
	return 0;

}
