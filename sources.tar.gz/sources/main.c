#include "stdio.h"
#include "sum.h"

int main(int argc, char** argv){

	if(argc < 3){
	
		printf("Too few arguments\n");
	}
	else{
	
		int result = Sum(atoi(argv[1]), atoi(argv[2]));
	}

	return 0;

}
