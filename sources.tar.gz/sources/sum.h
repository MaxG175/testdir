#ifndef SUM_H
#define SUM_H

int Sum(int, int);

#endif
