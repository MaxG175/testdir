#include "sum.h"

int Sum(int a, int b){

	int result = 0;
	if(a > b){
	
		result = a - b;
	}
	else{
	
		result = a + b;
	}

	return result;

}
